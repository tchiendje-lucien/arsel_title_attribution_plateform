<header>
    <nav id="navbar">
        <h1 class="logo"><a href="#">Filter App</a></h1>

        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
</header>