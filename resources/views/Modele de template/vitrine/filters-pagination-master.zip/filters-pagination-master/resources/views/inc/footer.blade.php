<footer id="main-footer">
    <p>Filter App &copy; 2020, All Right Reserved</p>
</footer>