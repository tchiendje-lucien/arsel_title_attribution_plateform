<div class="container-1">
    <input type="text" placeholder="Search..." id="search" />
</div>